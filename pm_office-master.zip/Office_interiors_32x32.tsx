<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Office_interiors_32x32" tilewidth="32" tileheight="32" tilecount="528" columns="22">
 <image source="Office_interiors_32x32.png" width="704" height="768"/>
</tileset>
