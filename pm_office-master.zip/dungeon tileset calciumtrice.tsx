<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="dungeon tileset calciumtrice" tilewidth="32" tileheight="32" tilecount="255" columns="15">
 <image source="../dungeon tileset calciumtrice.png" width="480" height="560"/>
</tileset>
