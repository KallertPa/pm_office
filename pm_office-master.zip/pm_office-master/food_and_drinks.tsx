<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="food_and_drinks" tilewidth="32" tileheight="32" tilecount="1024" columns="16">
 <image source="food_and_drinks.png" width="512" height="2048"/>
</tileset>
