<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="kitchen" tilewidth="32" tileheight="32" tilecount="56" columns="7">
 <image source="kitchen.png" width="224" height="256"/>
</tileset>
