<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Tileset_32x32_3" tilewidth="32" tileheight="32" tilecount="100" columns="10">
 <image source="Tileset_32x32_3.png" width="320" height="320"/>
</tileset>
