<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Office_walls_floors_32x32" tilewidth="32" tileheight="32" tilecount="192" columns="16">
 <image source="Office_walls_floors_32x32.png" width="512" height="384"/>
</tileset>
