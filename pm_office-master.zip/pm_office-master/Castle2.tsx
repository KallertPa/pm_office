<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Castle2" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="../Castle2.png" width="512" height="512"/>
</tileset>
