<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="inside" tilewidth="32" tileheight="32" tilecount="160" columns="16">
 <image source="../inside/inside/inside.png" width="512" height="336"/>
</tileset>
