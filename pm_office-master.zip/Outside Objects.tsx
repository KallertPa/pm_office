<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Outside Objects" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="../LPC Submissions Merged 2.0/Outside Objects.png" width="1024" height="1024"/>
</tileset>
