<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="CampFireFinished" tilewidth="32" tileheight="32" tilecount="20" columns="10">
 <image source="../CampFireFinished.png" width="320" height="64"/>
</tileset>
