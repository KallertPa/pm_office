<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="city_inside" tilewidth="32" tileheight="32" tilecount="384" columns="24">
 <image source="../LPC_city_inside/city_inside.png" width="768" height="512"/>
</tileset>
